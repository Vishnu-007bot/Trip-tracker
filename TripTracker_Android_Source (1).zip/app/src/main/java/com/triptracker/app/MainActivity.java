package com.triptracker.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.os.Build;
import android.os.Bundle;
import android.webkit.GeolocationPermissions;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.widget.EditText;
import android.view.ViewGroup;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private WebView webView;
    private SharedPreferences prefs;
    private static final int LOCATION_REQ = 1001;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        prefs = getSharedPreferences("triptracker", MODE_PRIVATE);
        webView = new WebView(this);
        setContentView(webView, new ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(true);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(
                    String origin, GeolocationPermissions.Callback callback) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, true, false);
                } else {
                    requestPermissions(new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    }, LOCATION_REQ);
                    callback.invoke(origin, false, false);
                }
            }
        });

        String url = prefs.getString("url", "");
        if (url.isEmpty()) askForUrl();
        else loadApp(url);
    }

    private void askForUrl() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("https://script.google.com/macros/s/.../exec");
        new AlertDialog.Builder(this)
            .setTitle("Connect Trip Tracker")
            .setMessage("Paste your deployed Google Apps Script web app URL ending in /exec.")
            .setView(input)
            .setCancelable(false)
            .setPositiveButton("Open", (d, w) -> {
                String url = input.getText().toString().trim();
                if (!url.startsWith("https://script.google.com/") || !url.contains("/exec")) {
                    new AlertDialog.Builder(this).setMessage("Please enter the Google Apps Script web app URL ending in /exec.")
                        .setPositiveButton("Try again", (dd, ww) -> askForUrl()).show();
                    return;
                }
                prefs.edit().putString("url", url).apply();
                loadApp(url);
            }).show();
    }

    private void loadApp(String url) {
        webView.loadUrl(url);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else new AlertDialog.Builder(this).setMessage("Exit Trip Tracker?")
            .setNegativeButton("Stay", null).setPositiveButton("Exit", (d,w) -> finish()).show();
    }
}
