TRIP TRACKER ANDROID APP — MOBILE-FRIENDLY BUILD PACKAGE

This is an Android WebView wrapper for your existing Google Apps Script Trip Tracker.
It asks for your deployed Apps Script URL the first time it opens, then saves it.

IMPORTANT
- This ZIP is Android source code, not a precompiled APK.
- The Google Apps Script backend must be deployed before the app can actually work.
- A cloud build (GitHub Actions) can compile the APK; you do not need Android Studio
  on your phone, but setting up the GitHub repository is easiest in desktop mode.
- The app needs internet and location permission. Location sharing is sensitive;
  share group codes only with people you trust.

BACKEND DEPLOYMENT (Google Apps Script)
1. Visit https://script.google.com/ and create a new project.
2. Paste the supplied Code.gs into the script editor.
3. Add an HTML file named Index, paste the supplied Index.html, and save.
4. Deploy > New deployment > Web app.
5. Execute as: Me. Who has access: Anyone (or the access option you intend).
6. Authorize, deploy, and copy the URL ending in /exec.

BUILD APK USING GITHUB ACTIONS
1. On GitHub, create a new repository named TripTrackerAndroid.
2. Upload the contents of this ZIP (not the ZIP itself) to the repository root,
   preserving the .github/workflows/build-apk.yml path. Ensure hidden files/folders
   such as .github are included. If the mobile upload UI hides dot-folders, use
   GitHub's desktop-site view or a computer for this one setup step.
3. Commit to the main branch.
4. Open the repository's Actions tab and select "Build Trip Tracker APK".
5. Tap "Run workflow" if it did not start automatically.
6. When complete, open the successful run and download the artifact named
   TripTracker-debug-apk. Unzip it to get app-debug.apk.
7. On your Android phone, open the APK and approve installing from that source if
   Android asks. Only install APKs you built from this project/repository.

FIRST LAUNCH
Paste the deployed Google Apps Script /exec URL into the app.
Join a group with a name and shared group code, then grant location permission.

NOTES
- This is a debug APK for testing, not a Play Store release.
- Google Apps Script quotas, Maps service availability, Android WebView restrictions,
  and background-location limitations may affect behavior.
- For sustained live location while the app is backgrounded, a native foreground
  location service and additional Android permissions would be needed. This wrapper
  is best used while the app is open.
