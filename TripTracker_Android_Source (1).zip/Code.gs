/**
 * TRIP TRACKER - Bike & Car group trips
 * Features: live GPS map of all members, group chat, SOS, navigator (Google Directions),
 * trip recording (distance / max speed / duration).
 *
 * SETUP: paste this as Code.gs, add Index.html, then Deploy > New deployment > Web app
 *        Execute as: Me | Who has access: Anyone
 * The database spreadsheet "TripTracker DB" is created automatically on first run.
 */

const CFG = {
  ONLINE_SECONDS: 45,      // member shown as "live" if last ping is newer than this
  CHAT_LOOKBACK_ROWS: 150, // rows scanned per poll
  KEEP_POINTS_DAYS: 30     // used by cleanup()
};

/* ---------- Web app entry ---------- */
function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('Trip Tracker')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1, viewport-fit=cover')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/* ---------- Database ---------- */
const SHEETS = {
  Members: ['group', 'uid', 'name', 'vehicle', 'lat', 'lng', 'speedKmh', 'heading', 'acc', 'battery', 'ts', 'tripId', 'sharing'],
  Points:  ['ts', 'group', 'uid', 'tripId', 'lat', 'lng', 'speedKmh'],
  Chat:    ['ts', 'group', 'uid', 'name', 'text', 'type'],
  Trips:   ['tripId', 'group', 'uid', 'name', 'vehicle', 'startTs', 'endTs', 'distKm', 'maxKmh', 'status']
};

function db_() {
  const props = PropertiesService.getScriptProperties();
  let id = props.getProperty('DB_ID');
  let ss;
  if (id) {
    ss = SpreadsheetApp.openById(id);
  } else {
    ss = SpreadsheetApp.create('TripTracker DB');
    props.setProperty('DB_ID', ss.getId());
  }
  Object.keys(SHEETS).forEach(function (name) {
    if (!ss.getSheetByName(name)) {
      const sh = ss.insertSheet(name);
      sh.appendRow(SHEETS[name]);
      sh.setFrozenRows(1);
    }
  });
  const def = ss.getSheetByName('Sheet1');
  if (def) ss.deleteSheet(def);
  return ss;
}

function sheet_(name) { return db_().getSheetByName(name); }

function withLock_(fn) {
  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try { return fn(); } finally { lock.releaseLock(); }
}

function clean_(s, max) {
  return String(s == null ? '' : s).replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, max || 60);
}

function groupKey_(g) { return clean_(g, 30).toUpperCase().replace(/[^A-Z0-9_-]/g, ''); }

/* ---------- Members cache (fast polling) ---------- */
function readMembers_(group) {
  const cache = CacheService.getScriptCache();
  const hit = cache.get('m_' + group);
  if (hit) return JSON.parse(hit);
  const sh = sheet_('Members');
  const last = sh.getLastRow();
  const out = {};
  if (last > 1) {
    sh.getRange(2, 1, last - 1, 13).getValues().forEach(function (r) {
      if (r[0] === group) {
        out[r[1]] = { uid: r[1], name: r[2], vehicle: r[3], lat: r[4], lng: r[5], speed: r[6],
                      heading: r[7], acc: r[8], battery: r[9], ts: r[10], tripId: r[11], sharing: r[12] === 1 };
      }
    });
  }
  cache.put('m_' + group, JSON.stringify(out), 60);
  return out;
}

function upsertMember_(group, m) {
  const sh = sheet_('Members');
  const last = sh.getLastRow();
  let row = -1;
  if (last > 1) {
    const keys = sh.getRange(2, 1, last - 1, 2).getValues();
    for (let i = 0; i < keys.length; i++) {
      if (keys[i][0] === group && keys[i][1] === m.uid) { row = i + 2; break; }
    }
  }
  const vals = [group, m.uid, m.name, m.vehicle, m.lat, m.lng, m.speed, m.heading, m.acc, m.battery, m.ts, m.tripId || '', m.sharing ? 1 : 0];
  if (row < 0) sh.appendRow(vals); else sh.getRange(row, 1, 1, vals.length).setValues([vals]);
  const members = readMembers_(group);
  members[m.uid] = m;
  CacheService.getScriptCache().put('m_' + group, JSON.stringify(members), 60);
}

/* ---------- API (called with google.script.run) ---------- */

/** Join / re-join a group. */
function api_join(group, uid, name, vehicle) {
  group = groupKey_(group);
  if (!group) throw new Error('Enter a group code (letters and numbers).');
  name = clean_(name, 24) || 'Rider';
  vehicle = vehicle === 'car' ? 'car' : 'bike';
  uid = clean_(uid, 40);
  return withLock_(function () {
    const old = readMembers_(group)[uid] || {};
    upsertMember_(group, {
      uid: uid, name: name, vehicle: vehicle, lat: old.lat || '', lng: old.lng || '', speed: 0,
      heading: 0, acc: 0, battery: '', ts: Date.now(), tripId: old.tripId || '', sharing: false
    });
    sheet_('Chat').appendRow([Date.now(), group, uid, name, name + ' joined the group', 'sys']);
    return { group: group, name: name, vehicle: vehicle };
  });
}

/**
 * One call per poll: pushes my position (if sharing) and returns members + new chat.
 * p = {group, uid, pos:{lat,lng,speed,heading,acc}|null, battery, tripId, lastChat}
 */
function api_sync(p) {
  const group = groupKey_(p.group);
  const now = Date.now();
  if (p.pos && isFinite(p.pos.lat) && isFinite(p.pos.lng)) {
    withLock_(function () {
      const me = readMembers_(group)[p.uid];
      if (!me) throw new Error('Join the group first.');
      upsertMember_(group, {
        uid: p.uid, name: me.name, vehicle: me.vehicle,
        lat: +p.pos.lat, lng: +p.pos.lng,
        speed: Math.round((+p.pos.speed || 0) * 10) / 10,
        heading: Math.round(+p.pos.heading || 0), acc: Math.round(+p.pos.acc || 0),
        battery: p.battery == null ? '' : Math.round(p.battery), ts: now,
        tripId: p.tripId || '', sharing: true
      });
      if (p.tripId) {
        sheet_('Points').appendRow([now, group, p.uid, p.tripId, +p.pos.lat, +p.pos.lng, +p.pos.speed || 0]);
      }
    });
  }

  const members = readMembers_(group);
  const list = Object.keys(members).map(function (k) {
    const m = members[k];
    m.live = m.sharing && (now - m.ts) / 1000 < CFG.ONLINE_SECONDS;
    return m;
  });

  const chatSh = sheet_('Chat');
  const last = chatSh.getLastRow();
  const msgs = [];
  if (last > 1) {
    const start = Math.max(2, last - CFG.CHAT_LOOKBACK_ROWS + 1);
    chatSh.getRange(start, 1, last - start + 1, 6).getValues().forEach(function (r) {
      if (r[1] === group && r[0] > (+p.lastChat || 0)) {
        msgs.push({ ts: r[0], uid: r[2], name: r[3], text: r[4], type: r[5] });
      }
    });
  }
  return { now: now, members: list, chat: msgs };
}

function api_share(group, uid, on) {
  group = groupKey_(group);
  withLock_(function () {
    const me = readMembers_(group)[uid];
    if (!me) return;
    me.sharing = !!on;
    upsertMember_(group, me);
  });
  return true;
}

/** type: 'msg' | 'sos' | 'loc' */
function api_chat(group, uid, text, type) {
  group = groupKey_(group);
  const me = readMembers_(group)[uid];
  if (!me) throw new Error('Join the group first.');
  text = clean_(text, 500);
  if (!text) return false;
  type = ['sos', 'loc'].indexOf(type) >= 0 ? type : 'msg';
  withLock_(function () { sheet_('Chat').appendRow([Date.now(), group, uid, me.name, text, type]); });
  return true;
}

function api_startTrip(group, uid) {
  group = groupKey_(group);
  const me = readMembers_(group)[uid];
  if (!me) throw new Error('Join the group first.');
  const tripId = 'T' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
  withLock_(function () {
    sheet_('Trips').appendRow([tripId, group, uid, me.name, me.vehicle, Date.now(), '', 0, 0, 'active']);
    sheet_('Chat').appendRow([Date.now(), group, uid, me.name, me.name + ' started a trip', 'sys']);
  });
  return tripId;
}

function api_endTrip(group, uid, tripId, distKm, maxKmh) {
  group = groupKey_(group);
  return withLock_(function () {
    const sh = sheet_('Trips');
    const last = sh.getLastRow();
    if (last > 1) {
      const ids = sh.getRange(2, 1, last - 1, 1).getValues();
      for (let i = 0; i < ids.length; i++) {
        if (ids[i][0] === tripId) {
          const row = i + 2;
          sh.getRange(row, 7, 1, 4).setValues([[Date.now(), Math.round(distKm * 100) / 100, Math.round(maxKmh), 'done']]);
          const me = readMembers_(group)[uid];
          if (me) {
            me.tripId = '';
            upsertMember_(group, me);
            sheet_('Chat').appendRow([Date.now(), group, uid, me.name,
              me.name + ' finished the trip: ' + (Math.round(distKm * 10) / 10) + ' km', 'sys']);
          }
          return true;
        }
      }
    }
    return false;
  });
}

function api_trips(group) {
  group = groupKey_(group);
  const sh = sheet_('Trips');
  const last = sh.getLastRow();
  const out = [];
  if (last > 1) {
    sh.getRange(2, 1, last - 1, 10).getValues().forEach(function (r) {
      if (r[1] === group) {
        out.push({ tripId: r[0], name: r[3], vehicle: r[4], startTs: r[5], endTs: r[6], distKm: r[7], maxKmh: r[8], status: r[9] });
      }
    });
  }
  return out.reverse().slice(0, 25);
}

/** Trail points of one trip, for replay on the map. */
function api_tripPoints(tripId) {
  const sh = sheet_('Points');
  const last = sh.getLastRow();
  const out = [];
  if (last > 1) {
    sh.getRange(2, 1, last - 1, 7).getValues().forEach(function (r) {
      if (r[3] === tripId) out.push([r[4], r[5]]);
    });
  }
  return out;
}

/* ---------- Navigator (Google Maps service) ---------- */

/** Turn a place name / address into coordinates. */
function api_geocode(query, nearLat, nearLng) {
  const g = Maps.newGeocoder().setRegion('in');
  const res = g.geocode(clean_(query, 120));
  if (res.status !== 'OK' || !res.results.length) throw new Error('Place not found. Try a more specific name.');
  const r = res.results[0];
  return { lat: r.geometry.location.lat, lng: r.geometry.location.lng, label: r.formatted_address };
}

/** mode: 'bike' | 'car'. Falls back to driving if cycling has no route. */
function api_route(origin, dest, mode) {
  function find(m) {
    return Maps.newDirectionFinder()
      .setOrigin(origin.lat, origin.lng)
      .setDestination(dest.lat, dest.lng)
      .setMode(m)
      .setRegion('in')
      .getDirections();
  }
  let note = '';
  let r = find(mode === 'bike' ? Maps.DirectionFinder.Mode.BICYCLING : Maps.DirectionFinder.Mode.DRIVING);
  if (r.status !== 'OK' && mode === 'bike') {
    r = find(Maps.DirectionFinder.Mode.DRIVING);
    note = 'No cycle route here, showing the road route.';
  }
  if (r.status !== 'OK' || !r.routes.length) throw new Error('No route found (' + r.status + ').');
  const route = r.routes[0];
  const leg = route.legs[0];
  return {
    polyline: route.overview_polyline.points,
    distance: leg.distance.text, distanceM: leg.distance.value,
    duration: leg.duration.text, durationS: leg.duration.value,
    note: note,
    steps: leg.steps.map(function (s) {
      return {
        text: String(s.html_instructions || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(),
        dist: s.distance.text,
        lat: s.end_location.lat, lng: s.end_location.lng
      };
    })
  };
}

/* ---------- Housekeeping: add a daily time-driven trigger for cleanup() ---------- */
function cleanup() {
  const cutoff = Date.now() - CFG.KEEP_POINTS_DAYS * 86400000;
  ['Points', 'Chat'].forEach(function (name) {
    const sh = sheet_(name);
    const last = sh.getLastRow();
    if (last < 2) return;
    const ts = sh.getRange(2, 1, last - 1, 1).getValues();
    let del = 0;
    while (del < ts.length && ts[del][0] < cutoff) del++;
    if (del > 0) sh.deleteRows(2, del);
  });
}
